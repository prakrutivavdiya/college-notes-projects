/* End of line character is #*/

#include<stdio.h>
int p=0;
char s[1000];
char l;

int S()
{
    if(l=='#')
    {
        return 0;
    }
    if(A())
    {
        l = s[p++];
        if(l=='#')
        {
            return 0;
        }
        if(B())
        {
            l = s[p++];
            if(l=='#')
            {
                return 0;
            }
            if(C())
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
    }
    else
    {
        return 0;
    }
}

int A()
{
    if(l=='#')
    {
        return 0;
    }
    if(l=='a')
    {
        l = s[p++];
        if(l=='#')
        {
            return 0;
        }
        if(A())
        {
            l = s[p++];
            if(l=='#')
            {
                return 0;
            }
            if(l=='b')
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
    }
    if(C())
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int B()
{
    if(l=='#')
    {
        return 0;
    }
    if(l=='c')
    {
        l = s[p++];
        if(l=='#')
        {
            return 0;
        }
        if(B())
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
    if(l=='d')
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int C()
{
    if(l=='#')
    {
        return 0;
    }
    if(l=='e')
    {
        l = s[p++];
        if(l=='#')
        {
            return 0;
        }
        if(C())
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
    if(l=='f')
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
main()
{
    printf("Enter a string:-");
    scanf("%s",s);
    l = s[p++];
    if(S())
    {
        l = s[p++];
        if(l=='#')
        {
            printf("Accepted\n");
        }
        else
        {
            printf("Error\n");
        }
    }
    else
    {
        printf("Error\n");      
    }
}

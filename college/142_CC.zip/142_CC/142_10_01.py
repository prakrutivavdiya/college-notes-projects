def maxpred():
    if "^" in s:
        return s.index("^")
    if "/" in s:
        return s.index("/")
    if "*" in s:
        return s.index("*")
    if "+" in s:
        return s.index("+")
    if "-" in s:
        return s.index("-")

def convert():
    global c,s,table
    flag=True
    while(flag):
        i=maxpred()
        c+=1
        table.append((c,s[i-1],s[i],s[i+1]))
        s=s.replace(s[i-1:i+2],str(c))
        if(len(s)==1):
            flag=False

c=0
table=[]
s="a+b*c^d"
convert()
print(table)
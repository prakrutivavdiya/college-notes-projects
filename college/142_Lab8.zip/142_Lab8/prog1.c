#include<stdio.h> 
#include<ctype.h> 
#include<string.h> 
int count, n = 0; 
char firstResult[10][100]; 
int m = 0,k,e; 
char grammer[10][10]; 
char f[10], first[10],ck; 
void findfirst(char, int, int); 
int main() 
{ 
	int jm = 0; 
	int km = 0; 
	int i, choice; 
	char c, ch; 
	count = 5; 
	
	strcpy(grammer[0], "S=aABb"); 
	strcpy(grammer[1], "A=c"); 
	strcpy(grammer[2], "A=#"); 
	strcpy(grammer[3], "B=d"); 
	strcpy(grammer[4], "B=#"); 
	int k1; 
	char done[count]; 
	int ptr = -1; 
	for(k = 0; k < count; k++) { 
		for(k1 = 0; k1 < 100; k1++) { 
			firstResult[k][k1] = '!'; 
		} 
	} 
	int p1 = 0, p2, x; 
	
	for(k = 0; k < count; k++) 
	{ 
		c = grammer[k][0]; 
		p2 = 0; 
		x = 0; 
		for(k1 = 0; k1 <= ptr; k1++) 
			if(c == done[k1]) 
				x = 1; 				
		if (x == 1) 
			continue; 
		findfirst(c, 0, 0); 
		ptr += 1;  
		done[ptr] = c; 
		printf("\n First(%c) = { ", c); 
		firstResult[p1][p2++] = c; 
		
		for(i = 0 + jm; i < n; i++) { 
			int l = 0, chk = 0; 
			
			for(l = 0; l < p2; l++) { 
				
				if (first[i] == firstResult[p1][l]) 
				{ 
					chk = 1; 
					break; 
				} 
			} 
			if(chk == 0) 
			{ 
				printf(" %c,", first[i]); 
				firstResult[p1][p2++] = first[i]; 
			} 
		} 
		printf("\b }\n"); 
		jm = n; 
		p1++; 
	} 
} 
void findfirst(char c, int q1, int q2) 
{ 
	int j; 
	if(!(isupper(c))) { 
		first[n++] = c; 
	} 
	for(j = 0; j < count; j++) 
	{ 
		if(grammer[j][0] == c) 
		{ 
			if(grammer[j][2] == '#') 
			{ 
				if(grammer[q1][q2] == '\0') 
					first[n++] = '#'; 
				else if(grammer[q1][q2] != '\0'
						&& (q1 != 0 || q2 != 0)) 
				{ 
					findfirst(grammer[q1][q2], q1, (q2+1)); 
				} 
				else
					first[n++] = '#'; 
			} 
			else if(!isupper(grammer[j][2])) 
			{ 
				first[n++] = grammer[j][2]; 
			} 
			else
			{ 
				findfirst(grammer[j][2], j, 3); 
			} 
		} 
	} 
} 
